# A Kraken API Client in Java
Query the Kraken API in Java. No external libraries used.

Execute `mvn clean package` and the JAR will be in the `target` folder. After that, `Examples.java` can also be executed using `java -cp target/classes edu/self/kraken/Examples`.

https://www.kraken.com/en-us/help/api
